export function SiteShell({ children, title }: { children: React.ReactNode; title?: string }) { return <div><header>{title}</header><main>{children}</main></div>; }
