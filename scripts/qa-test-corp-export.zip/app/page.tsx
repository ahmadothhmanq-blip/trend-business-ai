import { SiteShell } from "@/components/layout/site-shell";
import { Button } from "@/components/ui/button";
import { buildPageTitle } from "@/lib/seo";
export const metadata = {
  title: buildPageTitle("Home"),
  description: "Establish trust with executive buyers and move them toward consultation bookings.",
};
export default function HomePage() {
  return (
    <SiteShell
        title="QA AUTOSAVE TEST 2026 B">
      <h1>Home</h1>
      <p>Establish trust with executive buyers and move them toward consultation bookings.</p>
      <section><h2>hero</h2></section>
      <Button>Book a strategy workshop</Button>
    </SiteShell>
  );
}
