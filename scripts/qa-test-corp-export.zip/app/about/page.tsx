import { SiteShell } from "@/components/layout/site-shell";
export default function AboutPage() { return <SiteShell><h1>About</h1></SiteShell>; }
