export const siteName = "QA Test Corp";
export function buildPageTitle(pageTitle?: string) { return pageTitle ? `${pageTitle} | ${siteName}` : siteName; }
